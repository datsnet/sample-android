package jp.eclipsebook;

import java.util.*;

import android.app.Service;
import android.content.Intent;
import android.os.*;

public class MyService extends Service {
	public static final String SERVICE_ACTION = "myService_action";
	private int counter = 0;

	@Override
	public IBinder onBind(Intent arg0) {
		return new MyBinder();
	}

	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				counter++;
				Intent intent = new Intent(SERVICE_ACTION);
				intent.putExtra("counter", counter);
				sendBroadcast(intent);
			}

		}, 1000, 1000);
	}

	class MyBinder extends Binder {}

}
