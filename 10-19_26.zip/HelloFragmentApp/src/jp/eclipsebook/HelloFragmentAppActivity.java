package jp.eclipsebook;

import android.app.*;
import android.content.res.Configuration;
import android.os.Bundle;

public class HelloFragmentAppActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (getResources().getConfiguration().orientation == 
				Configuration.ORIENTATION_PORTRAIT) {
			setContentView(R.layout.tile);
		} else {
			setContentView(R.layout.main);
		}
	}
	
	public static class DetailsActivity extends Activity {
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			if (getResources().getConfiguration().orientation == 
					Configuration.ORIENTATION_LANDSCAPE) {
				finish();
				return;
			}
			DetailsFragment details = new DetailsFragment();
			details.setArguments(getIntent().getExtras());
			FragmentManager manager = getFragmentManager();
			FragmentTransaction transact = manager.beginTransaction();
			transact.add(android.R.id.content, details);
			transact.commit();
		}
	}
	
}