package jp.eclipsebook;

import android.app.*;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class TitlesFragment extends ListFragment {
	private boolean isDual;
	private int position = 0;
	private static String[] items = new String[] { 
			"Windows", "Mac OS X", "Linux" };

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		setListAdapter(new ArrayAdapter<String>(getActivity(),
				android.R.layout.simple_list_item_activated_1,items));
		View detailsFrame = getActivity().findViewById(R.id.details);
		isDual = detailsFrame != null
				&& detailsFrame.getVisibility() == View.VISIBLE;

		if (savedInstanceState != null) {
			position = savedInstanceState.getInt("curChoice", 0);
		}

		if (isDual) {
			getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);
			showDetails(position);
		}
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		outState.putInt("curChoice", position);
	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		showDetails(position);
	}

	void showDetails(int index) {
		position = index;
		if (isDual) {
			getListView().setItemChecked(index, true);
			FragmentManager manager = getFragmentManager();
			DetailsFragment details = (DetailsFragment)manager.
					findFragmentById(R.id.details);
			if (details == null || details.getShownIndex() != index) {
				details = DetailsFragment.newInstance(index);
				FragmentTransaction ft = manager.beginTransaction();
				ft.replace(R.id.details, details);
				ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
				ft.commit();
			}
		} else {
			Intent intent = new Intent();
			intent.setClass(getActivity(), HelloFragmentAppActivity.DetailsActivity.class);
			intent.putExtra("index", index);
			startActivity(intent);
		}
	}
}