package jp.eclipsebook;

import android.app.*;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	
	public void doAction(View view){
		final Activity activity = this;
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Message");
		final CharSequence[] items = {"Android","iPhone","Windows Phone"};
		final int[] sel_item = {0};
		builder.setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener(){
			@Override
			public void onClick(DialogInterface dialog, int which) {
				sel_item[0] = which;
				Toast toast = Toast.makeText(activity, "yout selected: " + which,
						Toast.LENGTH_SHORT);
				toast.show();
			}
		});
		builder.setNeutralButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				String msg = "selected: " + items[sel_item[0]];
				Toast toast = Toast.makeText(activity, msg,
						Toast.LENGTH_SHORT);
				toast.show();
			}
		});
		builder.show();
	}

}
