package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.GridView;

public class HelloAppActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		String[] items = {"One","Two","Three","Four","Five","Six","Seven"};
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				R.layout.item,items);
		GridView view1 = (GridView)this.findViewById(R.id.gridView1);
		view1.setAdapter(adapter);
	}

	public void doAction(View view){
		
	}
}

