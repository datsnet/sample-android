package jp.eclipsebook;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.*;

public class MyView extends View {
	private float lastX,lastY;

	public MyView(Context context) {
		super(context);
	}
	
	public MyView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public MyView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		canvas.drawColor(Color.WHITE);
		int w = canvas.getWidth();
		int h = canvas.getHeight();
		Paint paint = new Paint();
		paint.setColor(Color.argb(25,255,0,0));
		canvas.save();
		for(int i = 0;i < 10;i++){
			Rect r = new Rect(0, 0,w,h);
			canvas.drawRect(r, paint);
			canvas.translate(0, h / 10);
		}
		canvas.restore();
		paint.setColor(Color.argb(50,0,0,255));
		canvas.translate(lastX, lastY);
		for(int i = 1;i <= 5;i++){
			canvas.drawCircle(0, 0, 10 * i, paint);
		}
		paint.setColor(Color.WHITE);
		paint.setTextSize(24);
		canvas.drawText("x: " + lastX + " y: " + lastY, 0, 0, paint);
		canvas.restore();
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		lastX = event.getX();
		lastY = event.getY();
		invalidate();
		return true;
	}
	
}
