package jp.eclipsebook;

import android.app.Activity;
import android.location.*;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class HelloAppActivity extends Activity 
		implements LocationListener {
	private LocationManager manager;
	private TextView text1;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		text1 = (TextView) this.findViewById(R.id.text1);
	}

	public void doAction(View view) {
		manager = (LocationManager)this.getSystemService(LOCATION_SERVICE);
		manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
	}

	@Override
	public void onLocationChanged(Location location) {
		double lat = location.getLatitude();
		double lng = location.getLongitude();
		text1.setText("lat: " + lat + ", lng: " + lng);
		manager.removeUpdates(this);
	}

	@Override
	public void onProviderDisabled(String provider) {}

	@Override
	public void onProviderEnabled(String provider) {}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {}

}
