package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableRow;

public class HelloAppActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}

	public void doAction(View view){
		TableRow row1 = (TableRow)this.findViewById(R.id.tableRow1);
		Button btn = (Button)row1.getChildAt(1);
		btn.setWidth(btn.getWidth() + 25);
	}
}

