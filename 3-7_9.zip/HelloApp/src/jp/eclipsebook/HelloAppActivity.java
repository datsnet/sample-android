package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.*;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		final Activity activity = this;
		Spinner spinner = (Spinner)this.findViewById(R.id.spinner1);
		spinner.setOnItemSelectedListener(new OnItemSelectedListener(){
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, 
					int position, long id) {
				Spinner spinner = (Spinner)parent;
				String str = (String)spinner.getSelectedItem();
				Toast toast = Toast.makeText(activity, "you selected:" + str,
						Toast.LENGTH_SHORT);
				toast.show();
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				Toast toast = Toast.makeText(activity, "NOT selected...",
						Toast.LENGTH_SHORT);
				toast.show();
			}});
	}
}
