package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.widget.RatingBar.OnRatingBarChangeListener;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		final Activity activity = this;
		RatingBar rate1 = (RatingBar)this.findViewById(R.id.ratingBar1);
		rate1.setOnRatingBarChangeListener(new OnRatingBarChangeListener(){
			@Override
			public void onRatingChanged(RatingBar ratingBar, float rating,
					boolean fromUser) {
				Toast toast = Toast.makeText(activity, "rate: " + ratingBar.getRating(),
						Toast.LENGTH_SHORT);
				toast.show();
			}});
	}
}
