package jp.eclipsebook;

import android.app.*;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.*;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	
	public void doAction(View view){
		final Activity activity = this;
		EditText text1 = (EditText)this.findViewById(R.id.editText1);
		Editable str = text1.getText();
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Message");
		builder.setMessage("you typed: " + str);
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener(){
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Toast toast = Toast.makeText(activity, "OK!!",
						Toast.LENGTH_SHORT);
				toast.show();
			}
		});
		builder.setNeutralButton("...", new DialogInterface.OnClickListener(){
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Toast toast = Toast.makeText(activity, "...?",
						Toast.LENGTH_SHORT);
				toast.show();
			}
		});
		builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Toast toast = Toast.makeText(activity, "canceled...",
						Toast.LENGTH_SHORT);
				toast.show();
			}
		});
		builder.show();
	}
}
