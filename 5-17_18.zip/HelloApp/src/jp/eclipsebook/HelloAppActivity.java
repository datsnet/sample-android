package jp.eclipsebook;

import java.util.*;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		final Activity activity = this;
		String[] arr = {"Windows", "Mac", "Linux"};
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1,arr);
		final ListView list = (ListView)this.findViewById(R.id.listView1);
		list.setAdapter(adapter);
		list.setOnItemClickListener(new AdapterView.OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> adapter, View view, int arg2,
					long arg3) {
				TextView text1 = (TextView)view;
				Toast toast = Toast.makeText(activity, "you selected:" + text1.getText(),
						Toast.LENGTH_SHORT);
				toast.show();
			}});
	}

}
