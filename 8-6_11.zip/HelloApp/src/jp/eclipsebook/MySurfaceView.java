package jp.eclipsebook;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Calendar;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.provider.MediaStore;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class MySurfaceView extends SurfaceView 
		implements SurfaceHolder.Callback {
	private SurfaceHolder holder = null;
	private Camera camera;
	
	public MySurfaceView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initSurface();
	}

	public MySurfaceView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initSurface();
	}

	public MySurfaceView(Context context) {
		super(context);
		initSurface();
	}
	
	public void initSurface(){
		holder = this.getHolder();
		holder.addCallback(this);
		// holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS); // ��
	}
	
	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		camera = Camera.open();
		try {
			camera.setPreviewDisplay(holder);
		} catch (IOException exception) {
			exception.printStackTrace();
			camera.release();
			camera = null;
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int fprmat, 
			int width, int height) {
		camera.stopPreview();
		Camera.Parameters parameters = camera.getParameters();
		parameters.setPreviewSize(width,height);
		parameters.setPictureSize(width,height);
		camera.setParameters(parameters);
		camera.startPreview();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		camera.stopPreview();
		camera.release();
		camera = null;
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			camera.takePicture(null,null,new Camera.PictureCallback(){
				@Override
				public void onPictureTaken(byte[] data, Camera camera) {
					Calendar calendar = Calendar.getInstance();
					DateFormat format = DateFormat.getDateTimeInstance();
					String datestr = format.format(calendar.getTime());
					ContentResolver resolver = getContext().getContentResolver();
					Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length, null);
					MediaStore.Images.Media.insertImage(resolver, bmp, "my app captured",
							datestr);
					camera.startPreview();
				}
				
			});
		}
		return true;
	}
	
}
