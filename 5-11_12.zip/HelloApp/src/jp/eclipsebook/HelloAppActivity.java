package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.SlidingDrawer;
import android.widget.Toast;

public class HelloAppActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		final Activity activity = this;
		SlidingDrawer drawer = 
				(SlidingDrawer)this.findViewById(R.id.slidingdrawer);
		drawer.setOnDrawerOpenListener(new SlidingDrawer.OnDrawerOpenListener() {
			@Override
			public void onDrawerOpened() {
				Toast toast = Toast.makeText(activity, "open drawer!!", 
						Toast.LENGTH_SHORT);
				toast.show();
			}
		});
		drawer.setOnDrawerCloseListener(new SlidingDrawer.OnDrawerCloseListener() {
			@Override
			public void onDrawerClosed() {
					Toast toast = Toast.makeText(activity, "close drawer...", 
							Toast.LENGTH_SHORT);
				toast.show();
			}
		});
	}

	public void doAction(View view){
		
	}
}

