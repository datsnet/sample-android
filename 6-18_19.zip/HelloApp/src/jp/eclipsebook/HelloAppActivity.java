package jp.eclipsebook;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.*;

public class HelloAppActivity extends Activity {
	static final int HELLOAPPACTIVITY_CODE = 0;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	
	public void doAction(View view){
		EditText edit1 = (EditText)this.findViewById(R.id.editText1);
		EditText edit2 = (EditText)this.findViewById(R.id.editText2);
		EditText edit3 = (EditText)this.findViewById(R.id.editText3);
		Editable name1 = edit1.getText();
		Editable name2 = edit2.getText();
		Editable age = edit3.getText();
		MyData data = new MyData(name1.toString(),name2.toString(),age.toString());
		Intent intent = new Intent(Intent.ACTION_SEND);
		intent.setType("application/mydata");
		intent.putExtra("MyData",data);
		this.startActivityForResult(intent,HELLOAPPACTIVITY_CODE);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
		super.onActivityResult(requestCode, resultCode, intent);
		if (requestCode == HELLOAPPACTIVITY_CODE){
			if (resultCode == Activity.RESULT_OK){
				String result = "";
				try {
					result = (String)intent.getExtras().
							getCharSequence(Intent.EXTRA_TEXT);
				} catch (NullPointerException e) {
					result = e.getMessage();
				}
				Toast toast = Toast.makeText(this, result, 
						Toast.LENGTH_SHORT);
				toast.show();
			} else {
				Toast toast = Toast.makeText(this, "no result...", 
						Toast.LENGTH_SHORT);
				toast.show();
			}
		}
	}
}
