package jp.eclipsebook;

import java.util.concurrent.*;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.*;

public class MySurfaceView extends SurfaceView 
		implements SurfaceHolder.Callback {
	private SurfaceHolder holder = null;
	float lastX,lastY,nextX,nextY;
	int lastColor;
	
	public MySurfaceView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initSurface();
	}

	public MySurfaceView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initSurface();
	}

	public MySurfaceView(Context context) {
		super(context);
		initSurface();
	}
	
	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		drawSurface();
		doAnim();
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int fprmat, 
			int width, int height) {}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {}

	public void initSurface(){
		lastColor = Color.WHITE;
		nextX = 100;
		nextY = 100;
		holder = this.getHolder();
		holder.addCallback(this);
	}
	
	public void drawSurface(){
		Canvas canvas = holder.lockCanvas();
		canvas.drawColor(Color.WHITE);
		Paint paint = new Paint();
		paint.setColor(Color.RED);
		paint.setAlpha(25);
		for(int i = 1;i <= 5;i++){
			canvas.drawCircle(lastX, lastY, 10 * i, paint);
		}
		holder.unlockCanvasAndPost(canvas);
	}
	
	public void doAnim(){
		ScheduledExecutorService executor = 
				Executors.newSingleThreadScheduledExecutor();
		executor.scheduleAtFixedRate(new Runnable(){
			@Override
			public void run() {
				lastX -= (lastX - nextX) / 20;
				lastY -= (lastY - nextY) / 20;
				lastX = Math.abs(lastX) < 1.0f ? 1.0f : lastX;
				lastY = Math.abs(lastY) < 1.0f ? 1.0f : lastY;
				drawSurface();
			}}, 0, 100, TimeUnit.MILLISECONDS);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		nextX = event.getX();
		nextY = event.getY();
		return true;
	}
	
}
