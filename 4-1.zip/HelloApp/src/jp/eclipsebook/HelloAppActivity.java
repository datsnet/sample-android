package jp.eclipsebook;

import android.app.*;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	
	public void doAction(View view){
		EditText text1 = (EditText)this.findViewById(R.id.editText1);
		Editable str = text1.getText();
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage("you typed: " + str);
		builder.show();
	}
}
