package jp.eclipsebook;

import android.app.*;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	
	public void doAction(View view){
		final Activity activity = this;
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Message");
		final CharSequence[] items = {"Android","iPhone","Windows Phone"};
		final boolean[] item_checked = {false, false, false};
		builder.setMultiChoiceItems(items, null, new DialogInterface
				.OnMultiChoiceClickListener(){
			@Override
			public void onClick(DialogInterface dialog, int which, 
					boolean isChecked) {
				item_checked[which] = isChecked;
				if (isChecked){
					Toast toast = Toast.makeText(activity, "yout checked: " + 
							items[which], Toast.LENGTH_SHORT);
					toast.show();
				}
			}
		});
		builder.setNeutralButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				String msg = "*selected item*";
				for(int i = 0;i < item_checked.length;i++){
					if (item_checked[i]){
						msg += "\n" + items[i];
					}
				}
				Toast toast = Toast.makeText(activity, msg,
						Toast.LENGTH_SHORT);
				toast.show();
			}
		});
		builder.show();
	}

}
