package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class HelloAppActivity extends Activity {
	private TextView text1;
	private EditText edit1;
	private Button btn1;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		final Activity activity = this;
		// ListView�쐬
		LinearLayout layout = new LinearLayout(this);
		layout.setOrientation(LinearLayout.VERTICAL);
		this.setContentView(layout);
		// TextView�쐬
		text1 = new TextView(this);
		text1.setText("dynamic widget!");
		text1.setTextSize(30);
		layout.addView(text1);
		// EditText�쐬
		edit1 = new EditText(this);
		edit1.setTextSize(30);
		layout.addView(edit1);
		// Button�쐬
		btn1 = new Button(this);
		btn1.setText("Click");
		layout.addView(btn1);
		// Button�̃C�x���g�ݒ�
		btn1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Toast toast = Toast.makeText(activity, "you typed: " + 
						edit1.getText(), Toast.LENGTH_SHORT);
				toast.show();
			}
		});
	}
}
