package jp.eclipsebook;

import android.appwidget.AppWidgetProvider;

public class MyWidgetProvider extends AppWidgetProvider {

}
