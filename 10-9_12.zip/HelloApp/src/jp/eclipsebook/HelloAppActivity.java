package jp.eclipsebook;

import android.app.Activity;
import android.content.*;
import android.os.*;
import android.view.View;
import android.widget.TextView;

public class HelloAppActivity extends Activity {
	private TextView text1 = null;
	private MyReceiver receiver = null;
	private MyConnection connection = null;
	private MyService.MyBinder binder = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		text1 = (TextView) this.findViewById(R.id.text1);
	}

	public void doAction(View view) {
		connection = new MyConnection();
		Intent intent = new Intent(this, MyService.class);
		this.startService(intent);
		receiver = new MyReceiver();
		IntentFilter filter = new IntentFilter(MyService.SERVICE_ACTION);
		this.registerReceiver(receiver, filter);
		this.bindService(intent, connection, Context.BIND_AUTO_CREATE);
	}

	public void showMsg(int counter) {
		text1.setText("count: " + counter);
	}

	public void doInit(View view) {
		if (binder != null){
			binder.initial();
		}
	}
	
	@Override
	protected void onDestroy() {
		Intent intent = new Intent(this, MyService.class);
		this.stopService(intent);
		super.onDestroy();
	}

	class MyConnection implements ServiceConnection {
		
		@Override
		public void onServiceConnected(ComponentName className, IBinder service) {
			binder = (MyService.MyBinder)service;
		}

		@Override
		public void onServiceDisconnected(ComponentName className) {
			binder = null;
		}

	}

	class MyReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			int counter = intent.getIntExtra("counter", 0);
			HelloAppActivity app = (HelloAppActivity) context;
			app.showMsg(counter);
		}

	}
}
