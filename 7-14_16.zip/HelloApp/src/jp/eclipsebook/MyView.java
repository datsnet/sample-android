package jp.eclipsebook;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;

public class MyView extends View {
	private float loc = 50f;
	private String msg = "";

	public MyView(Context context) {
		super(context);
	}

	public MyView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public MyView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}
	
	public float getLoc() { return loc; }
	public void setLoc(float loc) { this.loc = loc; }
	public String getMsg() { return msg; }
	public void setMsg(String msg) { this.msg = msg; }

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		canvas.drawColor(Color.WHITE);
		Paint paint = new Paint();
		try {
			paint.setColor(Color.parseColor(msg));
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (StringIndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		canvas.drawCircle(loc ,loc,50,paint);
		loc += 10f;
	}
}
