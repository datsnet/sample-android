package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	
	public void doAction(View view){
		MyView myview = (MyView)this.findViewById(R.id.myview1);
		EditText edit1 = (EditText)this.findViewById(R.id.edit1);
		String s = edit1.getText().toString();
		myview.setMsg(s);
		myview.invalidate();
	}
	
}
