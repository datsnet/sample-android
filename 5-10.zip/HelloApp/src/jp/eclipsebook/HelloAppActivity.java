package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.Toast;

public class HelloAppActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		final Activity activity = this;
		String[] items = {"One","Two","Three","Four","Five","Six","Seven"};
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				R.layout.item,items);
		GridView view1 = (GridView)this.findViewById(R.id.gridView1);
		view1.setAdapter(adapter);
		view1.setOnItemClickListener(new AdapterView.OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> adapter, View view,
					int arg2, long arg3) {
				Toast toast = Toast.makeText(activity, "you clicked: " + arg2 , 
						Toast.LENGTH_SHORT);
				toast.show();
			}});
	}

	public void doAction(View view){
		
	}
}

