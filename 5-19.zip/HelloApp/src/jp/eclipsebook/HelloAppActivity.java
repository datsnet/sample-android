package jp.eclipsebook;

import java.util.*;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class HelloAppActivity extends Activity {
	private int counter = 0;
	private ArrayAdapter<String> arrayadapter = null;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		List<String> arr = new ArrayList<String>();
		arr.add("First item");
		arrayadapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1,arr);
		final ListView list = (ListView)this.findViewById(R.id.listView1);
		list.setAdapter(arrayadapter);
		
		list.setOnItemClickListener(new AdapterView.OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> adapter, View view, 
					int arg2, long arg3) {
				arrayadapter.add("No," + ++counter);
			}});
		list.setOnItemLongClickListener(new AdapterView.
				OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> adapter, View view,
					int arg2, long arg3) {
				TextView text = (TextView)view;
				arrayadapter.remove((String)text.getText());
				return true;
			}
		});
	}

}
