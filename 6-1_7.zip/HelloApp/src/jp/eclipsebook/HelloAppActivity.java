package jp.eclipsebook;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.*;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	
	public void doAction(View view){
		final Activity activity = this;
		EditText edit1 = (EditText)this.findViewById(R.id.editText1);
		Editable str = edit1.getText();
		TextView text1 = (TextView)this.findViewById(R.id.text1);
		text1.setText("you typed: " + str);
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Message");
		builder.setMessage("change activity.");
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener(){
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Intent intent = new Intent(activity,jp.eclipsebook.OtherActivity.class);
				activity.startActivity(intent);
			}
		});
		builder.setNegativeButton("Cancel", null);
		builder.show();
	}
}
