package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HelloAppActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}

	public void doAction(View view){
		final Activity activity = this;
		Button btn = (Button)view;
		btn.setWidth(btn.getWidth()*2);
		btn.setHeight(btn.getHeight()*2);
	}
}

