package jp.eclipsebook;

import android.app.*;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		final Activity activity = this;
		Button button = (Button)this.findViewById(R.id.button1);
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Toast toast = Toast.makeText(activity, "on Click!",
						Toast.LENGTH_SHORT);
				toast.show();
			}
		});
		button.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View v) {
				Toast toast = Toast.makeText(activity, "on Long Click...",
						Toast.LENGTH_SHORT);
				toast.show();
				return false;
			}
		});
	}

}
