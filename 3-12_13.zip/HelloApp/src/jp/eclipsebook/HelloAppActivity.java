package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		final Activity activity = this;
		final TextView text1 = (TextView)this.findViewById(R.id.text1);
		SeekBar bar1 = (SeekBar)this.findViewById(R.id.seekBar1);
		bar1.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				text1.setText("value: " + progress);
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				Toast toast = Toast.makeText(activity, "Start!",
						Toast.LENGTH_SHORT);
				toast.show();
			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				Toast toast = Toast.makeText(activity, "Stop...",
						Toast.LENGTH_SHORT);
				toast.show();
			}});
	}
}
