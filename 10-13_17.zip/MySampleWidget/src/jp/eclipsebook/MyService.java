package jp.eclipsebook;

import android.app.*;
import android.appwidget.AppWidgetManager;
import android.content.*;
import android.os.IBinder;
import android.widget.RemoteViews;

public class MyService extends Service {
	public static final int REQ_CODE = 0;
	public static final String ACTION_BTNCLICK = "jp.eclipsebook.MyService.ACTION_BTNCLICK";
	private int counter = 0;

	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);

		AppWidgetManager manager = AppWidgetManager.getInstance(this);

		RemoteViews view = new RemoteViews(getPackageName(), R.layout.item);
		Intent newintent = new Intent(ACTION_BTNCLICK);
		PendingIntent pending = PendingIntent.getService(this, 
				REQ_CODE, newintent, PendingIntent.FLAG_UPDATE_CURRENT);
		view.setOnClickPendingIntent(R.id.widgetBtn1, pending);
		if (ACTION_BTNCLICK.equals(intent.getAction())) {
			btnClicked(view);
		}
		ComponentName widget = new ComponentName(this, 
				MyWidgetProvider.class);
		manager.updateAppWidget(widget, view);
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	public void btnClicked(RemoteViews view) {
		view.setTextViewText(R.id.widgetText1, "count:" + ++counter);
	}
}
