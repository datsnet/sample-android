package jp.eclipsebook;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.*;

public class MySurfaceView extends SurfaceView 
		implements SurfaceHolder.Callback {
	private SurfaceHolder holder = null;
	
	public MySurfaceView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initSurface();
	}

	public MySurfaceView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initSurface();
	}

	public MySurfaceView(Context context) {
		super(context);
		initSurface();
	}
	
	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		drawSurface();
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int fprmat, 
			int width, int height) {}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {}

	public void initSurface(){
		holder = this.getHolder();
		holder.addCallback(this);
	}
	
	public void drawSurface(){
		Canvas canvas = holder.lockCanvas();
		canvas.drawColor(Color.WHITE);
		Paint paint = new Paint();
		paint.setColor(Color.RED);
		canvas.drawCircle(100, 100, 50, paint);
		holder.unlockCanvasAndPost(canvas);
	}

}
