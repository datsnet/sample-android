package jp.eclipsebook;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.TimePicker;
import android.widget.Toast;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	
	public void doAction(View view){
		final Activity activity = this;
			TimePickerDialog dlog = new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener(){
			@Override
			public void onTimeSet(TimePicker view, int h, int m) {
				Toast toast = Toast.makeText(activity,  "" + h + ":" + m, Toast.LENGTH_SHORT);
				toast.show();
			}
		},0,0,true);
		dlog.show();
	}

}
