package jp.eclipsebook;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;

public class MyView extends View {

	public MyView(Context context) {
		super(context);
	}

	public MyView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public MyView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		canvas.drawColor(Color.WHITE);
		Paint paint = new Paint();
		for(int i = 0;i < 10;i++){
			paint.setColor(Color.argb(150,255 - i * 25,255,255));
			canvas.drawCircle(100 + i * 25,100 + i * 25,50,paint);
		}
		
	}
}
