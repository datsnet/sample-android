package jp.eclipsebook;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;

public class MyView extends View {

	public MyView(Context context) {
		super(context);
	}

	public MyView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public MyView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		canvas.drawColor(Color.WHITE);
		Paint paint = new Paint();
		paint.setTextSize(40.0f);
		paint.setTextAlign(Paint.Align.LEFT);
		paint.setTypeface(Typeface.SANS_SERIF);
		paint.setTextScaleX(1.5f);
		paint.setTextSkewX(-0.5f);
		canvas.drawText("Welcome!!", 50, 50, paint);
	}
}
