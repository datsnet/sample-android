package jp.eclipsebook;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.*;

public class MyView extends View {
	private float lastX,lastY;

	public MyView(Context context) {
		super(context);
	}

	public MyView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public MyView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		canvas.drawColor(Color.WHITE);
		Paint paint = new Paint();
		paint.setColor(Color.RED);
		paint.setShadowLayer(5f, 10, 10, Color.GRAY);
		canvas.drawCircle(lastX, lastY, 50, paint);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		lastX = event.getX();
		lastY = event.getY();
		invalidate();
		return true;
	}
	
}
