package jp.eclipsebook;

import android.app.*;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	
	public void doAction(View view){
		final Activity activity = this;
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Message");
		final CharSequence[] items = {"Android","iPhone","Windows Phone"};
		builder.setItems(items, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Toast toast = Toast.makeText(activity, "yout Selected: " + items[which],
						Toast.LENGTH_SHORT);
				toast.show();
			}
		});
		builder.show();
	}
}
