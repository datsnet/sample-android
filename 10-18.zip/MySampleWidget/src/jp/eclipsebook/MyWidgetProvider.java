package jp.eclipsebook;

import android.appwidget.*;
import android.content.*;

public class MyWidgetProvider extends AppWidgetProvider {

	@Override
	public void onUpdate(Context context, AppWidgetManager manager,
			int[] appWidgetIds) {
		Intent serviceIntent = new Intent(context, MyService.class);
		context.startService(serviceIntent);
	}
	
}
