package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HelloAppActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		Button btn = (Button)this.findViewById(R.id.button1);
		btn.setOnClickListener(
			new View.OnClickListener(){
				public void onClick(View v) {
					TextView text1 = (TextView)findViewById(R.id.text1);
					text1.setText("ok!");
				}
			}
		);
	}
}
