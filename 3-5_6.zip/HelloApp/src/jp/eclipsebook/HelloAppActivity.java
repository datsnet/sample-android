package jp.eclipsebook;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class HelloAppActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		final Activity activity = this;
		RadioGroup group1 = (RadioGroup)this.findViewById(R.id.radioGroup1);
		group1.setOnCheckedChangeListener(new OnCheckedChangeListener(){
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				RadioButton btn = (RadioButton)findViewById(checkedId);
				Toast toast = Toast.makeText(activity, "you checked: " + btn.getText(),
						Toast.LENGTH_SHORT);
				toast.show();
			}
		});
	}
}
