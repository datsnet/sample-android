package jp.eclipsebook;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class OtherActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.other);
	}
	
	public void doAction(View view){
		Intent intent = new Intent(this,jp.eclipsebook.HelloAppActivity.class);
		this.startActivity(intent);
	}
}
