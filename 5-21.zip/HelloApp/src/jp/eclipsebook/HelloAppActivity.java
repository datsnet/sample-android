package jp.eclipsebook;

import java.util.*;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class HelloAppActivity extends ListActivity {
	private ArrayAdapter<String> arrayadapter = null;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		final ListActivity activity = this;
		ListView list = this.getListView();
		list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		List<String> arr = new ArrayList<String>();
		arr.add("First item");
		arr.add("Second item");
		arr.add("Third item");
		arrayadapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_single_choice,arr);
		this.setListAdapter(arrayadapter);
		list.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> adapter, View v,
					int position, long id) {
				TextView text = (TextView)v;
				Toast toast = Toast.makeText(activity, "you selected:" + position + 
						":" + text.getText(),
						Toast.LENGTH_SHORT);
				toast.show();
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) { }
		});
	}
	
}
