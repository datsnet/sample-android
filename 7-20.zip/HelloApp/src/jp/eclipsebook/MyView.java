package jp.eclipsebook;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.*;

public class MyView extends View {
	private Bitmap bitmap = null;

	public MyView(Context context) {
		super(context);
		init(context);
	}
	
	public MyView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}

	public MyView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context);
	}
	
	private void init(Context context){
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		int w = canvas.getWidth();
		int h = canvas.getHeight();
		canvas.drawColor(Color.WHITE);
		Paint paint = new Paint();
		paint.setColor(Color.argb(50, 255, 0, 0));
		canvas.translate(w /2 , h / 2 - 200);
		for(int i = 0;i < 50;i++){
			canvas.scale(0.95f, 0.95f);
			canvas.rotate(19f);
			canvas.drawRect(new Rect(0, 0, 200, 200), paint);
		}
	}
	
}
